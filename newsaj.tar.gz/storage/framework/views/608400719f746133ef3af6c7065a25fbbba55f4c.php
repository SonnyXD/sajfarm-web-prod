<?php foreach($attributes->onlyProps(['action' => '', 'method' => 'POST', 'id' => 'action-form', 'class' => 'forms-sample']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['action' => '', 'method' => 'POST', 'id' => 'action-form', 'class' => 'forms-sample']); ?>
<?php foreach (array_filter((['action' => '', 'method' => 'POST', 'id' => 'action-form', 'class' => 'forms-sample']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<form action="<?php echo e($action); ?>" method="<?php echo e($method); ?>" id="<?php echo e($id); ?>" class="<?php echo e($class); ?>">
    <?php echo csrf_field(); ?>
    <?php echo e($slot); ?>

</form><?php /**PATH /Users/cristimamota/newsaj/resources/views/components/form.blade.php ENDPATH**/ ?>