<?php foreach($attributes->onlyProps(['class' => 'form-control', 'id' => '', 'name' => '']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['class' => 'form-control', 'id' => '', 'name' => '']); ?>
<?php foreach (array_filter((['class' => 'form-control', 'id' => '', 'name' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<select id="<?php echo e($id); ?>" class="<?php echo e($class); ?>" name="<?php echo e($name); ?>">
    <?php echo e($slot); ?>

</select>
<?php /**PATH /Users/cristimamota/newsaj/resources/views/components/select.blade.php ENDPATH**/ ?>