<?php foreach($attributes->onlyProps(['type' => 'text', 'class' => 'form-control', 'id' => '', 'placeholder' => '', 'name' => '', 'disabled' => '', 'value' => '']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['type' => 'text', 'class' => 'form-control', 'id' => '', 'placeholder' => '', 'name' => '', 'disabled' => '', 'value' => '']); ?>
<?php foreach (array_filter((['type' => 'text', 'class' => 'form-control', 'id' => '', 'placeholder' => '', 'name' => '', 'disabled' => '', 'value' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<input type="<?php echo e($type); ?>" id="<?php echo e($id); ?>" class="<?php echo e($class); ?>" placeholder="<?php echo e($placeholder); ?>" name="<?php echo e($name); ?>" value="<?php echo e($value); ?>"<?php echo e($disabled); ?>>
<?php /**PATH /Users/cristimamota/newsaj/resources/views/components/input.blade.php ENDPATH**/ ?>