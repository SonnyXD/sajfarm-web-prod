<?php foreach($attributes->onlyProps(['type' => 'button', 'class' => 'btn btn-info', 'id' => '', 'data_bs_toggle' => 'modal', 'data_bs_target' => '#meds-modal', 'data_bs_dismiss' => '']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['type' => 'button', 'class' => 'btn btn-info', 'id' => '', 'data_bs_toggle' => 'modal', 'data_bs_target' => '#meds-modal', 'data_bs_dismiss' => '']); ?>
<?php foreach (array_filter((['type' => 'button', 'class' => 'btn btn-info', 'id' => '', 'data_bs_toggle' => 'modal', 'data_bs_target' => '#meds-modal', 'data_bs_dismiss' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<button type="<?php echo e($type); ?>" class="<?php echo e($class); ?>" id="<?php echo e($id); ?>" data-bs-toggle="<?php echo e($data_bs_toggle); ?>" data-bs-target="<?php echo e($data_bs_target); ?>"><?php echo e($slot); ?></button>
<?php /**PATH /Users/cristimamota/newsaj/resources/views/components/modal-trigger.blade.php ENDPATH**/ ?>