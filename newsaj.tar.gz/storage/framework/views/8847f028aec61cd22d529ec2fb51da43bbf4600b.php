<div class="home-tab">
  <div class="d-sm-flex align-items-center justify-content-between border-bottom">
    <ul class="nav nav-tabs" role="tablist">

      <?php if( $categories->count() ): ?>

        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="nav-item">
            <a class="nav-link ps-0" id="<?php echo e($category->slug); ?>-tab" href="<?php echo e($category->slug); ?>" role="tab" aria-controls="overview" data-title="<?php echo e($category->name); ?>" aria-selected="true"><?php echo e($category->name); ?></a>
          </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      <?php endif; ?>

      <!-- <li class="nav-item">
        <a class="nav-link ps-0" id="med-tab" data-title="Medicamente" href="medicamente" role="tab" aria-controls="overview" aria-selected="true">Medicamente</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" id="mat-tab" data-title="Materiale Sanitare" href="materiale-sanitare" role="tab" aria-selected="false">Materiale Sanitare</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" id="dez-tab" data-title="Dezinfectanti" href="dezinfectanti" role="tab" aria-selected="false">Dezinfectanti</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" id="spon-tab" data-title="Sponsorizari" href="sponsorizari" role="tab" aria-selected="false">Sponsorizari</a>
      </li>
      <li class="nav-item">
        <a class="nav-link border-0" id="don-tab" data-title="Donatii" href="donatii" role="tab" aria-selected="false">Donatii</a>
      </li> -->
    </ul>
  </div>
  <div class="tab-content tab-content-basic">

  </div>
</div><?php /**PATH /Users/cristimamota/newsaj/resources/views/components/subgestions.blade.php ENDPATH**/ ?>