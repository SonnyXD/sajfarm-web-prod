<?php foreach($attributes->onlyProps(['category_name' => '', 'items' => '']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['category_name' => '', 'items' => '']); ?>
<?php foreach (array_filter((['category_name' => '', 'items' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<input type="text" id="myInput" onkeyup="myFunction()" placeholder="Cauta..">
<div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title" id="section-title">
                  <?php echo e($category_name); ?>

                  </h4>
                  <div class="table-responsive">
                    <table class="table table-striped" id="medstable">
                      <thead>
                        <tr class="header">
                          <th>
                            Nume
                          </th>
                          <th>
                            Cantitate Totala
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php if( $items->count() ): ?>
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr data-count="<?php echo e($loop->index); ?>">
                            <td> <?php echo e($item->name); ?></td>
                            <td> 150 / 0 </td>
                          </tr>
                          <tr class="treeview tr-<?php echo e($loop->index); ?>"> <!-- Cod CIM	Cod Produs	Nume	Cantitate	Termen Valabilitate	Lot	UM	Pret Unitar	TVA	Pret TVA -->
                            <td colspan="100%">
                              <table>
                                <thead>
                                <tr>
                                  <?php if( $item->category_id == 1): ?>
                                    <th>Cod CIM</th>
                                  <?php endif; ?>
                                  <th>Cod Produs</th>
                                  <th>Cantitate</th>
                                  <th>Termen Valab</th>
                                  <th>Lot</th>
                                  <th>UM</th>
                                  <th>Pret Unitar</th>
                                  <th>TVA</th>
                                  <th>Pret TVA</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                  <td>&nbsp;</td>
                                  <td>&nbsp;</td>
                                  <td>&nbsp;</td>
                                  <td>&nbsp;</td>
                                </tr>
                                <tr>
                                  <td>&nbsp;</td>
                                  <td>&nbsp;</td>
                                  <td>&nbsp;</td>
                                  <td>&nbsp;</td>
                                </tr>
                                <tr>
                                  <td>&nbsp;</td>
                                  <td>&nbsp;</td>
                                  <td>&nbsp;</td>
                                  <td>&nbsp;</td>
                                </tr>
                                <tr>
                                  <td>&nbsp;</td>
                                  <td>&nbsp;</td>
                                  <td>&nbsp;</td>
                                  <td>&nbsp;</td>
                                </tr>
                                </tbody>
                              </table>
                            </td>
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php endif; ?>
                        <!-- <tr>
                          <td> Algocalmin pentru copii</td>
                          <td> 150 </td>
                        </tr>
                        <tr>
                          <td> Nurofen </td>
                          <td> 500 </td>
                        </tr>
                        <tr>
                          <td> Algocalmin pentru copii</td>
                          <td> 150 </td>
                        </tr>
                        <tr>
                          <td> Nurofen </td>
                          <td> 500 </td>
                        </tr>
                        <tr>
                          <td> Algocalmin pentru copii</td>
                          <td> 150 </td>
                        </tr>
                        <tr>
                          <td> Nurofen </td>
                          <td> 500 </td>
                        </tr>
                        <tr>
                          <td> Algocalmin pentru copii</td>
                          <td> 150 </td>
                        </tr>
                        <tr>
                          <td> Nurofen </td>
                          <td> 500 </td>
                        </tr>
                        <tr>
                          <td> Algocalmin pentru copii</td>
                          <td> 150 </td>
                        </tr>
                        <tr>
                          <td> Nurofen </td>
                          <td> 500 </td>
                        </tr> -->
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>

            <?php /**PATH /Users/cristimamota/newsaj/resources/views/components/medstable.blade.php ENDPATH**/ ?>