<div class="col-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Formular</h4>
                  <p class="card-description">
                    Completeaza formularul cu datele aferente
                  </p>
                  {{$slot}}
                </div>
              </div>
            </div>