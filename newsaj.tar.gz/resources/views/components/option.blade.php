@props(['value' => ''])

<option value="{{$value}}">
</option>
