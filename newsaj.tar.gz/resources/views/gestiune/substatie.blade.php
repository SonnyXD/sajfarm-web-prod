<x-layout>
    <x-substable :substations="$substations" :items="$items"/>          
</x-layout>