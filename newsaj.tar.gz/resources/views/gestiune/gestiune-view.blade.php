<x-layout>
    <x-subgestions/>
    <x-medstable :category_name="$current_category->name" :items="$items"/>
</x-layout>