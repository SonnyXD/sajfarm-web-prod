<x-layout>
    <x-container>
        <x-form id="expirare-6-luni">
            <div class="form-group">
                <x-button>Genereaza documentul</x-button>
            </div>
        </x-form>
    </x-container>
</x-layout>