<x-layout>
    <x-container>
        <x-form id="database">
        <div class="form-group">
        <label for="select-id">Alege</label>
        <select class="form-control" id="form-select">
            <option disabled selected>Alege o optiune..</option>
            <option value="nomenclator">Nomenclator</option>
            <option value="substatie">Substatie</option>
            <option value="tip-ambulanta">Tip Ambulanta</option>
            <option value="ambulanta">Ambulanta</option>
            <option value="furnizor">Furnizor</option>
            <option value="medic">Medic</option>
            <option value="asistent">Asistent</option>
            <option value="unitate">Unitate Masura</option>
        </select>
    </div>
        </x-form>
    </x-container>
    
</x-layout>