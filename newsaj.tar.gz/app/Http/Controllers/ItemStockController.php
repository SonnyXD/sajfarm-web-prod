<?php

namespace App\Http\Controllers;

use App\Models\Item_stock;
use Illuminate\Http\Request;

class ItemStockController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Item_stock  $item_stock
     * @return \Illuminate\Http\Response
     */
    public function show(Item_stock $item_stock)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Item_stock  $item_stock
     * @return \Illuminate\Http\Response
     */
    public function edit(Item_stock $item_stock)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Item_stock  $item_stock
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Item_stock $item_stock)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Item_stock  $item_stock
     * @return \Illuminate\Http\Response
     */
    public function destroy(Item_stock $item_stock)
    {
        //
    }
}
